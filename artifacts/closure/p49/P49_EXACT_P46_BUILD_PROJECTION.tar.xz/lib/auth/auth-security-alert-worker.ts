import { randomUUID } from "node:crypto";
import { emitAuthSecurityAlert, type AuthSecurityAlertPayload } from "@/lib/observability/auth-security-alert-sink";
import { runRegisteredServiceRoleRpc, type SupabaseRpcOperation } from "@/lib/db/supabase-rpc-operation-registry";

type RpcRunner=(input:{operation:SupabaseRpcOperation;args?:Record<string,unknown>})=>Promise<{data:unknown}>;
export type AuthSecurityAlertWorkerDependencies={rpc:RpcRunner;emit:typeof emitAuthSecurityAlert;workerToken:()=>string};
export const authSecurityAlertWorkerDependencies:AuthSecurityAlertWorkerDependencies={rpc:runRegisteredServiceRoleRpc,emit:emitAuthSecurityAlert,workerToken:randomUUID};
type AlertRow={id:number;event_family:AuthSecurityAlertPayload["eventFamily"];outcome:AuthSecurityAlertPayload["outcome"];severity:AuthSecurityAlertPayload["severity"];event_count:number;time_bucket:string};
function rows(data:unknown):AlertRow[]{return Array.isArray(data)?data.filter((x):x is AlertRow=>Boolean(x&&typeof x==="object")):[];}
export async function runAuthSecurityAlertWorker(input:{limit?:number;leaseSeconds?:number}={},dependencies:AuthSecurityAlertWorkerDependencies=authSecurityAlertWorkerDependencies){
  const limit=Math.max(1,Math.min(Math.trunc(input.limit??20),100)); const leaseSeconds=Math.max(15,Math.min(Math.trunc(input.leaseSeconds??60),300)); const workerToken=dependencies.workerToken();
  const claimed=await dependencies.rpc({operation:"auth_alert_worker_claim",args:{p_limit:limit,p_lease_seconds:leaseSeconds,p_worker_token:workerToken}});
  const items=rows(claimed.data); const summary={schemaVersion:"velmere.auth-security-alert-worker.v1" as const,claimed:items.length,delivered:0,retried:0,deadLettered:0,notConfigured:0};
  for(const item of items){
    const delivery=await dependencies.emit({schemaVersion:"velmere.auth-security-alert.v1",severity:item.severity,eventFamily:item.event_family,outcome:item.outcome,eventCount:Math.max(1,Math.min(item.event_count,1_000_000)),timeBucket:new Date(item.time_bucket).toISOString()});
    const delivered=delivery.state==="delivered"; const errorCode=delivery.state==="failed"?delivery.errorCode:delivery.state==="not_configured"?"alert_sink_not_configured":"";
    const settled=await dependencies.rpc({operation:"auth_alert_event_settle",args:{p_id:item.id,p_worker_token:workerToken,p_delivered:delivered,p_error_code:errorCode}});
    const status=String(settled.data??""); if(delivered)summary.delivered+=1; else if(status==="dead_letter")summary.deadLettered+=1; else summary.retried+=1; if(delivery.state==="not_configured")summary.notConfigured+=1;
  }
  return summary;
}
