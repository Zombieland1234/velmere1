import { invokeLazyRouteHandler } from "@/lib/server/lazy-route-dispatch";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export function POST(request: Request) {
  return invokeLazyRouteHandler({ method: "POST", request, load: () => import("@/lib/server/lazy-route-modules/security--audit-review--pro--settle"), unavailableError: "route_temporarily_unavailable" });
}
