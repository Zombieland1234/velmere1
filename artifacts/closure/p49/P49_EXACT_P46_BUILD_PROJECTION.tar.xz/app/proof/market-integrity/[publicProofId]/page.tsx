import type { Metadata } from "next";
import { sha256Digest, sha256Token } from "@/lib/security/cryptographic-digest";

const BOUNDARY =
  "pass4560-public-proof-verifier-redacted-metadata-only-no-customer-payload-no-paid-unlock-no-trade-execution-no-binary-pdf-no-token-material";
const PASS4561_BOUNDARY =
  "pass4561-public-proof-verification-receipt-redaction-seal-metadata-only-no-customer-payload-no-paid-unlock-no-trade-execution-no-binary-pdf-no-token-material";
const PASS4562_BOUNDARY =
  "pass4562-public-proof-audit-trail-digest-only-no-customer-payload-no-token-material-no-private-report-fields";

type PublicProofPageProps = {
  params: Promise<{ publicProofId: string }>;
};

function safeProofId(value: string) {
  return (
    String(value || "pubidx-missing")
      .replace(/[^a-zA-Z0-9._:-]/g, "-")
      .slice(0, 160) || "pubidx-missing"
  );
}


export async function generateMetadata({
  params,
}: PublicProofPageProps): Promise<Metadata> {
  const { publicProofId } = await params;
  const proofId = safeProofId(publicProofId);
  return {
    title: `Velmère Public Proof · ${proofId}`,
    description:
      "Redacted metadata-only public proof index for a Velmère market integrity report.",
    robots: {
      index: false,
      follow: false,
    },
  };
}

export default async function PublicMarketIntegrityProofPage({
  params,
}: PublicProofPageProps) {
  const { publicProofId } = await params;
  const proofId = safeProofId(publicProofId);
  const verifierDigest = sha256Digest(
    JSON.stringify({ proofId, boundary: BOUNDARY, route: "public-proof" }),
  );
  const verificationReceiptId = `vpr-${sha256Token(`${proofId}:${verifierDigest}:receipt`, 20)}`;
  const redactionSealHash = sha256Digest(
    JSON.stringify({
      proofId,
      verifierDigest,
      publicRoute: `/proof/market-integrity/${proofId}`,
      boundary: PASS4561_BOUNDARY,
      customerPayloadExposed: false,
    }),
  );
  const auditTrailHash = sha256Digest(
    JSON.stringify({
      proofId,
      verificationReceiptId,
      auditRoute: `/proof/market-integrity/${proofId}/audit-trail`,
      boundary: PASS4562_BOUNDARY,
      privateReportFieldsExposed: false,
    }),
  );
  const lanes = [
    ["public index", "redacted metadata route", proofId],
    ["payload boundary", "customer payload withheld", BOUNDARY],
    ["verifier", "digest-only check", verifierDigest],
    ["redaction seal", "verification receipt ready", redactionSealHash],
    ["audit trail", "digest-only history ready", auditTrailHash],
    ["next step", "operator can reconcile in Account Reports", "no binary PDF claim"],
  ];

  return (
    <main
      className="pass4560-public-proof-page"
    >
      <section className="pass4560-public-proof-shell">
        <div className="pass4560-public-proof-kicker">VELMÈRE PUBLIC PROOF</div>
        <h1>Redacted market integrity proof.</h1>
        <p>
          This route is a public transparency surface for a report proof index. It
          exposes only redacted metadata, route binding and digest information;
          it does not expose customer payloads, paid unlock state, raw report
          data, token material or binary PDF files.
        </p>
        <div className="pass4560-public-proof-grid">
          <span>
            <small>Proof index</small>
            <strong>{proofId}</strong>
          </span>
          <span>
            <small>Verifier digest</small>
            <strong>{verifierDigest}</strong>
          </span>
          <span>
            <small>Status</small>
            <strong>redacted metadata ready</strong>
          </span>
          <span>
            <small>Verification receipt</small>
            <strong>{verificationReceiptId}</strong>
          </span>
          <span>
            <small>Redaction seal</small>
            <strong>{redactionSealHash}</strong>
          </span>
        </div>
        <div className="pass4560-public-proof-lanes">
          {lanes.map(([lane, state, proof]) => (
            <span key={lane}>
              <b>{lane}</b>
              <em>{state}</em>
              <small>{proof}</small>
            </span>
          ))}
        </div>
        <div className="pass4560-public-proof-actions">
          <a href={`/proof/market-integrity/${proofId}/verify`}>Open verification receipt</a>
          <a href={`/proof/market-integrity/${proofId}/audit-trail`}>Open audit trail</a>
          <span>Audit trail: digest-only history</span>
        </div>
        <div className="pass4560-public-proof-boundary">
          <b>Boundary</b>
          <span>{BOUNDARY}</span>
        </div>
        <div className="pass4561-public-proof-receipt-seal">
          <b>Verification receipt</b>
          <span>{verificationReceiptId}</span>
          <small>{PASS4561_BOUNDARY}</small>
        </div>
        <div className="pass4562-public-proof-audit-seal">
          <b>Audit trail</b>
          <span>{auditTrailHash}</span>
          <small>{PASS4562_BOUNDARY}</small>
        </div>
      </section>
    </main>
  );
}
