import type { Metadata } from "next";
import { sha256Digest } from "@/lib/security/cryptographic-digest";

const BOUNDARY =
  "pass4561-public-proof-verification-receipt-redacted-metadata-only-no-customer-payload-no-paid-unlock-no-trade-execution-no-binary-pdf-no-token-material-no-raw-verifier-payload";

type PublicProofVerifyPageProps = {
  params: Promise<{ publicProofId: string }>;
};

function safeProofId(value: string) {
  return (
    String(value || "pubidx-missing")
      .replace(/[^a-zA-Z0-9._:-]/g, "-")
      .slice(0, 160) || "pubidx-missing"
  );
}


export async function generateMetadata({
  params,
}: PublicProofVerifyPageProps): Promise<Metadata> {
  const { publicProofId } = await params;
  const proofId = safeProofId(publicProofId);
  return {
    title: `Velmère Proof Verification · ${proofId}`,
    description:
      "Redacted metadata-only verification receipt for a Velmère public market integrity proof.",
    robots: {
      index: false,
      follow: false,
    },
  };
}

export default async function PublicMarketIntegrityProofVerifyPage({
  params,
}: PublicProofVerifyPageProps) {
  const { publicProofId } = await params;
  const proofId = safeProofId(publicProofId);
  const publicProofRoute = `/proof/market-integrity/${proofId}`;
  const publicVerifierRoute = `${publicProofRoute}/verify`;
  const auditTrailRoute = `${publicProofRoute}/audit-trail`;
  const verifierDigest = sha256Digest(
    JSON.stringify({ proofId, publicProofRoute, boundary: "pass4560" }),
  );
  const receiptDigest = sha256Digest(
    JSON.stringify({ proofId, publicVerifierRoute, verifierDigest, boundary: BOUNDARY }),
  );
  const lanes = [
    ["verifier intake", "digest-only verifier accepted", verifierDigest],
    ["route binding", "public proof route matches verify route", publicVerifierRoute],
    ["redaction", "customer payload and raw report data withheld", "metadata-only"],
    ["receipt seal", "verification receipt sealed", receiptDigest],
    ["audit trail", "digest-only audit trail ready", auditTrailRoute],
  ];

  return (
    <main
      className="pass4561-public-proof-verify-page"
    >
      <section className="pass4561-public-proof-verify-shell">
        <div className="pass4561-public-proof-verify-kicker">
          VELMÈRE PUBLIC PROOF VERIFIER
        </div>
        <h1>Redacted verification receipt.</h1>
        <p>
          This verification page seals a digest-only receipt for the public proof
          route. It confirms route binding and redaction boundaries without
          exposing customer payloads, raw report data, paid unlock state, token
          material or binary PDF files.
        </p>
        <div className="pass4561-public-proof-verify-grid">
          <span>
            <small>Proof index</small>
            <strong>{proofId}</strong>
          </span>
          <span>
            <small>Verifier route</small>
            <strong>{publicVerifierRoute}</strong>
          </span>
          <span>
            <small>Receipt digest</small>
            <strong>{receiptDigest}</strong>
          </span>
        </div>
        <div className="pass4561-public-proof-verify-lanes">
          {lanes.map(([lane, state, proof]) => (
            <span key={lane}>
              <b>{lane}</b>
              <em>{state}</em>
              <small>{proof}</small>
            </span>
          ))}
        </div>
        <div className="pass4561-public-proof-verify-actions">
          <a href={publicProofRoute}>Back to public proof</a>
          <a href={auditTrailRoute}>Open audit trail</a>
          <code>{BOUNDARY}</code>
        </div>
      </section>
    </main>
  );
}
