import type { Metadata } from "next";
import { sha256Digest, sha256Token } from "@/lib/security/cryptographic-digest";

const BOUNDARY =
  "pass4562-public-proof-audit-trail-redacted-metadata-only-no-customer-payload-no-paid-unlock-no-trade-execution-no-binary-pdf-no-token-material-no-raw-verifier-payload-no-private-report-fields";

type PublicProofAuditTrailPageProps = {
  params: Promise<{ publicProofId: string }>;
};

function safeProofId(value: string) {
  return (
    String(value || "pubidx-missing")
      .replace(/[^a-zA-Z0-9._:-]/g, "-")
      .slice(0, 160) || "pubidx-missing"
  );
}


export async function generateMetadata({
  params,
}: PublicProofAuditTrailPageProps): Promise<Metadata> {
  const { publicProofId } = await params;
  const proofId = safeProofId(publicProofId);
  return {
    title: `Velmère Proof Audit Trail · ${proofId}`,
    description:
      "Redacted metadata-only audit trail for a Velmère public market integrity proof verification receipt.",
    robots: {
      index: false,
      follow: false,
    },
  };
}

export default async function PublicMarketIntegrityProofAuditTrailPage({
  params,
}: PublicProofAuditTrailPageProps) {
  const { publicProofId } = await params;
  const proofId = safeProofId(publicProofId);
  const publicProofRoute = `/proof/market-integrity/${proofId}`;
  const verificationRoute = `${publicProofRoute}/verify`;
  const auditTrailRoute = `${publicProofRoute}/audit-trail`;
  const verifierDigest = sha256Digest(
    JSON.stringify({ proofId, publicProofRoute, boundary: "pass4560" }),
  );
  const receiptDigest = sha256Digest(
    JSON.stringify({ proofId, verificationRoute, verifierDigest, boundary: "pass4561" }),
  );
  const archiveDigest = sha256Digest(
    JSON.stringify({ proofId, verificationRoute, auditTrailRoute, receiptDigest, boundary: BOUNDARY }),
  );
  const auditTrailId = `pat-${sha256Token(`${proofId}:${receiptDigest}:audit-trail`, 24)}`;
  const events = [
    ["Public index", "redacted proof route created", proofId],
    ["Verifier", "digest-only verification route bound", verifierDigest],
    ["Verification receipt", "redacted receipt sealed", receiptDigest],
    ["Audit trail", "digest-only archive trail sealed", archiveDigest],
    ["Boundary", "private report fields withheld", "no customer payload / no token material"],
  ];

  return (
    <main
      className="pass4562-public-proof-audit-page"
    >
      <section className="pass4562-public-proof-audit-shell">
        <div className="pass4562-public-proof-audit-kicker">
          VELMÈRE PUBLIC PROOF AUDIT TRAIL
        </div>
        <h1>Redacted audit trail.</h1>
        <p>
          This audit trail reconciles the public proof route and the verification
          receipt into a digest-only archive view. It intentionally withholds
          customer payloads, private report fields, paid unlock state, token
          material and binary PDF files.
        </p>
        <div className="pass4562-public-proof-audit-grid">
          <span>
            <small>Proof index</small>
            <strong>{proofId}</strong>
          </span>
          <span>
            <small>Audit trail</small>
            <strong>{auditTrailId}</strong>
          </span>
          <span>
            <small>Archive digest</small>
            <strong>{archiveDigest}</strong>
          </span>
          <span>
            <small>Status</small>
            <strong>public-audit-trail-sealed</strong>
          </span>
        </div>
        <div className="pass4562-public-proof-audit-events">
          {events.map(([step, state, proof]) => (
            <span key={step}>
              <b>{step}</b>
              <em>{state}</em>
              <small>{proof}</small>
            </span>
          ))}
        </div>
        <div className="pass4562-public-proof-audit-actions">
          <a href={publicProofRoute}>Back to public proof</a>
          <a href={verificationRoute}>Open verification receipt</a>
          <code>{BOUNDARY}</code>
        </div>
      </section>
    </main>
  );
}
