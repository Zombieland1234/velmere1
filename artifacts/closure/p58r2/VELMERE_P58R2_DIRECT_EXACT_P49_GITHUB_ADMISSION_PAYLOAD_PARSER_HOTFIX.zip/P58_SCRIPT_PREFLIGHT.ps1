[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$ScriptPath,
  [Parameter(Mandatory = $true)][string]$ResultPath
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

try {
  if (-not (Test-Path -LiteralPath $ScriptPath -PathType Leaf)) {
    throw ("Main PowerShell script is missing: {0}" -f $ScriptPath)
  }

  $tokens = $null
  $parseErrors = $null
  [System.Management.Automation.Language.Parser]::ParseFile(
    $ScriptPath,
    [ref]$tokens,
    [ref]$parseErrors
  ) | Out-Null

  $parseErrorList = @($parseErrors)
  if ($parseErrorList.Count -gt 0) {
    $messages = @(
      $parseErrorList | ForEach-Object {
        "{0} (line {1}, column {2})" -f $_.Message, $_.Extent.StartLineNumber, $_.Extent.StartColumnNumber
      }
    )

    $result = [ordered]@{
      schemaVersion = 'velmere.p58r2.parser-preflight-result.v1'
      packageRevision = 'P58R2_PARSER_HOTFIX'
      status = 'FAIL'
      phase = 'POWERSHELL_PARSER_PREFLIGHT'
      scriptPath = $ScriptPath
      powershellVersion = [string]$PSVersionTable.PSVersion
      parseErrorCount = $parseErrorList.Count
      errors = $messages
      endedAtUtc = [DateTime]::UtcNow.ToString('o')
    }
    $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ResultPath -Encoding utf8

    Write-Host '[P58R2] PowerShell parser preflight failed:' -ForegroundColor Red
    foreach ($message in $messages) {
      Write-Host (" - {0}" -f $message) -ForegroundColor Red
    }
    exit 90
  }

  Write-Host '[P58R2] PowerShell parser preflight: PASS.' -ForegroundColor Green
  exit 0
}
catch {
  $result = [ordered]@{
    schemaVersion = 'velmere.p58r2.parser-preflight-result.v1'
    packageRevision = 'P58R2_PARSER_HOTFIX'
    status = 'FAIL'
    phase = 'POWERSHELL_PARSER_PREFLIGHT'
    scriptPath = $ScriptPath
    powershellVersion = [string]$PSVersionTable.PSVersion
    parseErrorCount = $null
    errors = @($_.Exception.ToString())
    endedAtUtc = [DateTime]::UtcNow.ToString('o')
  }
  $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ResultPath -Encoding utf8

  Write-Host '[P58R2] Parser preflight could not run:' -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  exit 91
}
