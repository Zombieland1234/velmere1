@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "P58_SCRIPT=%~dp0APPLY_P58_P49_PAYLOAD.ps1"
set "P58_PREFLIGHT=%~dp0P58_SCRIPT_PREFLIGHT.ps1"
set "P58_RESULT=%~dp0P58_APPLY_RESULT.json"

if exist "%P58_RESULT%" del /f /q "%P58_RESULT%" >nul 2>&1

echo.
echo VELMERE P58R2 - EXACT P49 GITHUB ADMISSION - PARSER HOTFIX
echo This will first parse-check the PowerShell script, then clone/update the
echo dedicated Velmere branch, verify 15 exact files, commit and push them.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%P58_PREFLIGHT%" -ScriptPath "%P58_SCRIPT%" -ResultPath "%P58_RESULT%"
set "P58_PREFLIGHT_EXIT=%ERRORLEVEL%"
if not "%P58_PREFLIGHT_EXIT%"=="0" goto :failed

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%P58_SCRIPT%"
set "P58_EXIT=%ERRORLEVEL%"
if not "%P58_EXIT%"=="0" goto :failed

echo.
echo P58R2 admission completed. The GitHub Actions page should open automatically.
echo.
pause
exit /b 0

:failed
if not exist "%P58_RESULT%" (
  >"%P58_RESULT%" echo {"schemaVersion":"velmere.p58r2.wrapper-failure.v1","status":"FAIL","failure":"PowerShell exited before a structured result was written."}
)
echo.
echo P58R2 failed. Read P58_APPLY_RESULT.json in this folder.
echo.
pause
if defined P58_EXIT exit /b %P58_EXIT%
exit /b %P58_PREFLIGHT_EXIT%
