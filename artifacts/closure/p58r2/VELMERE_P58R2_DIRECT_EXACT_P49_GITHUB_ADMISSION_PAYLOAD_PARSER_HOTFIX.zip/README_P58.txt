VELMERE P58R2 — EXACT P49 GITHUB ADMISSION BRIDGE — PARSER HOTFIX
=================================================================

WHY THIS R2 EXISTS
The first P58 package stopped before any Git operation because Windows PowerShell
parsed "$LASTEXITCODE:" inside a double-quoted string as an invalid variable reference.
R2 replaces that interpolation with the format operator and adds a separate parser
preflight before the main script can touch the repository.

PURPOSE
This deterministic package moves the already verified 15-file P49 self-contained
projection transport into the dedicated GitHub branch and triggers the real native
Windows Server 2025 campaign.

CURRENT TRUTH
- The failed R1 launch performed no manifest verification, Git clone, commit, push or
  workflow start because parsing failed before script execution.
- Local exact P49 projection reconstruction remains PASS 1597/1597 files.
- Exact projection payload remains 20,952,834 bytes.
- Native Windows build credit remains WITHHELD until the triggered GitHub run finishes.

ONE-CLICK WINDOWS USE
1. Delete or ignore the old extracted P58 folder.
2. Extract this P58R2 ZIP to a normal local folder.
3. Double-click URUCHOM_P58.bat.
4. The wrapper first runs a real Windows PowerShell parser preflight. It performs no Git
   operation unless the parser reports zero errors.
5. Git may ask you to sign in to GitHub. Use the GitHub account that can push to
   Zombieland1234/velmere1.
6. The script verifies every package-bound byte, clones/updates the dedicated branch,
   verifies and copies the exact 15 files, commits, pushes and opens the workflow page.

DEFAULT LOCAL CHECKOUT
%USERPROFILE%\velmere-p58-admission

ADVANCED USE
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\APPLY_P58_P49_PAYLOAD.ps1 `
  -RepoPath "C:\path\to\your\existing-clean-checkout"

Use -NoPush to create and verify the commit without pushing it.
Use -NoBrowser to avoid opening the workflow page.

BOUND IDENTITIES
P49 payload ZIP bytes: 3104954
P49 payload ZIP SHA-256: 6d12de41968ee2c59979c5aad5cc311484b75a7ddf119961ecad34a4dba1d9a7
Target files: 15
Target projection: 1597 files / 20,952,834 bytes
Target path-set SHA-256: b8d9b3c2753e3f7f0c0b3a6054cf8c254d2a91b9c9c5d8f37310add478ac3f73
Target content aggregate SHA-256: 83fd00183e9d8a6c5ec1c27dba81ab99679e204b50e8f45f414a45abd2bd21b7

SAFETY
- A real PowerShell parser preflight runs before the main script.
- The main script verifies every manifest-bound package file before Git operations.
- The script refuses a dirty existing checkout.
- It writes only the 15 manifest-bound P49 files.
- Every payload source and Git destination byte is checked before commit.
- It does not change LIVE, saleEnabled or productionApproved.
- Global state remains NO_GO until downstream engineering and product gates pass.
