[CmdletBinding()]
param(
  [string]$RepoPath = "",
  [string]$RepoUrl = "https://github.com/Zombieland1234/velmere1.git",
  [string]$Branch = "velmere-p47-p46-build-projection-windows-20260815",
  [switch]$NoPush,
  [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$PackageRoot = Split-Path -Parent $PSCommandPath
$ManifestPath = Join-Path $PackageRoot 'P58_ADMISSION_PACKAGE_MANIFEST.json'
$ResultPath = Join-Path $PackageRoot 'P58_APPLY_RESULT.json'
$TempRoot = Join-Path ([IO.Path]::GetTempPath()) ("velmere-p58r2-" + [Guid]::NewGuid().ToString('N'))

function Write-Step {
  param([Parameter(Mandatory = $true)][string]$Message)
  Write-Host ("[P58R2] " + $Message)
}

function Invoke-GitChecked {
  param([Parameter(Mandatory = $true)][string[]]$Arguments)

  & git @Arguments
  $exitCode = $LASTEXITCODE
  if ($exitCode -ne 0) {
    throw ("git failed with exit code {0}: git {1}" -f $exitCode, ($Arguments -join ' '))
  }
}

function Assert-SafeRelativePath {
  param([Parameter(Mandatory = $true)][string]$RelativePath)

  if ([string]::IsNullOrWhiteSpace($RelativePath)) {
    throw 'Empty relative path in manifest.'
  }

  $normalized = $RelativePath.Replace('\', '/')
  if ($normalized.StartsWith('/') -or $normalized.Contains('../') -or $normalized -eq '..' -or $normalized.Contains(':')) {
    throw ("Unsafe relative path in manifest: {0}" -f $RelativePath)
  }
}

function Assert-FileIdentity {
  param(
    [Parameter(Mandatory = $true)][string]$Path,
    [Parameter(Mandatory = $true)][long]$ExpectedBytes,
    [Parameter(Mandatory = $true)][string]$ExpectedSha256
  )

  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
    throw ("Required file missing: {0}" -f $Path)
  }

  $item = Get-Item -LiteralPath $Path
  if ($item.Length -ne $ExpectedBytes) {
    throw ("Byte-length mismatch for {0}. Expected {1}, got {2}" -f $Path, $ExpectedBytes, $item.Length)
  }

  $digest = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($digest -ne $ExpectedSha256.ToLowerInvariant()) {
    throw ("SHA-256 mismatch for {0}. Expected {1}, got {2}" -f $Path, $ExpectedSha256, $digest)
  }
}

$result = [ordered]@{
  schemaVersion = 'velmere.p58r2.local-github-admission-result.v1'
  packageRevision = 'P58R2_PARSER_HOTFIX'
  status = 'IN_PROGRESS'
  branch = $Branch
  repoPath = $null
  commitSha = $null
  pushed = $false
  packageIdentityVerified = $false
  payloadIdentityVerified = $false
  targetFilesVerified = 0
  powershellVersion = [string]$PSVersionTable.PSVersion
  workflowUrl = 'https://github.com/Zombieland1234/velmere1/actions/workflows/p49-native-windows-p46-build-relevant-projection.yml'
  startedAtUtc = [DateTime]::UtcNow.ToString('o')
  endedAtUtc = $null
  failure = $null
}

try {
  Write-Step 'Loading the deterministic admission manifest.'
  if (-not (Test-Path -LiteralPath $ManifestPath -PathType Leaf)) {
    throw ("Admission manifest is missing: {0}" -f $ManifestPath)
  }
  $manifest = Get-Content -LiteralPath $ManifestPath -Raw -Encoding utf8 | ConvertFrom-Json

  Write-Step 'Verifying every manifest-bound package file before Git operations.'
  foreach ($packageEntry in $manifest.packageFilesExcludingManifest) {
    $packageRelative = [string]$packageEntry.path
    Assert-SafeRelativePath -RelativePath $packageRelative
    $packagePlatformPath = $packageRelative.Replace('/', [IO.Path]::DirectorySeparatorChar)
    $packageFile = Join-Path $PackageRoot $packagePlatformPath
    Assert-FileIdentity -Path $packageFile -ExpectedBytes ([long]$packageEntry.byteLength) -ExpectedSha256 ([string]$packageEntry.sha256)
  }
  $result.packageIdentityVerified = $true

  $payloadRelativePath = ([string]$manifest.payload.archivePath).Replace('/', [IO.Path]::DirectorySeparatorChar)
  $payloadPath = Join-Path $PackageRoot $payloadRelativePath
  Assert-FileIdentity -Path $payloadPath -ExpectedBytes ([long]$manifest.payload.byteLength) -ExpectedSha256 ([string]$manifest.payload.sha256)
  if ([int]$manifest.payload.targetFileCount -ne 15) {
    throw 'Unexpected target file count in manifest.'
  }
  $result.payloadIdentityVerified = $true

  if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw 'Git is not installed or is not available in PATH.'
  }

  if ([string]::IsNullOrWhiteSpace($RepoPath)) {
    $RepoPath = Join-Path $env:USERPROFILE 'velmere-p58-admission'
  }
  $RepoPath = [IO.Path]::GetFullPath($RepoPath)
  $result.repoPath = $RepoPath

  if (Test-Path -LiteralPath $RepoPath) {
    if (-not (Test-Path -LiteralPath (Join-Path $RepoPath '.git') -PathType Container)) {
      throw ("RepoPath exists but is not a Git checkout: {0}" -f $RepoPath)
    }

    $dirty = @(& git -C $RepoPath status --porcelain)
    $statusExitCode = $LASTEXITCODE
    if ($statusExitCode -ne 0) {
      throw ("Cannot read Git working-tree state; git status exited with {0}." -f $statusExitCode)
    }
    if ($dirty.Count -gt 0) {
      throw ("Existing checkout is not clean. Commit or stash the changes, or delete this directory: {0}" -f $RepoPath)
    }

    Write-Step 'Refreshing the dedicated branch from origin.'
    Invoke-GitChecked -Arguments @('-C', $RepoPath, 'fetch', 'origin', $Branch)
    Invoke-GitChecked -Arguments @('-C', $RepoPath, 'checkout', '-B', $Branch, ("origin/{0}" -f $Branch))
  }
  else {
    Write-Step 'Cloning the dedicated Velmere projection branch.'
    Invoke-GitChecked -Arguments @('clone', '--branch', $Branch, '--single-branch', $RepoUrl, $RepoPath)
  }

  Write-Step 'Extracting the exact 15-file P49 payload.'
  New-Item -ItemType Directory -Force -Path $TempRoot | Out-Null
  Expand-Archive -LiteralPath $payloadPath -DestinationPath $TempRoot -Force

  $targetPaths = @()
  foreach ($entry in $manifest.payload.targetFiles) {
    $relative = [string]$entry.path
    Assert-SafeRelativePath -RelativePath $relative
    $platformPath = $relative.Replace('/', [IO.Path]::DirectorySeparatorChar)
    $source = Join-Path $TempRoot $platformPath
    Assert-FileIdentity -Path $source -ExpectedBytes ([long]$entry.byteLength) -ExpectedSha256 ([string]$entry.sha256)

    $destination = Join-Path $RepoPath $platformPath
    $parent = Split-Path -Parent $destination
    New-Item -ItemType Directory -Force -Path $parent | Out-Null
    Copy-Item -LiteralPath $source -Destination $destination -Force
    Assert-FileIdentity -Path $destination -ExpectedBytes ([long]$entry.byteLength) -ExpectedSha256 ([string]$entry.sha256)

    $targetPaths += $relative
    $result.targetFilesVerified = [int]$result.targetFilesVerified + 1
  }

  if ([int]$result.targetFilesVerified -ne 15) {
    throw ("Expected 15 verified target files, got {0}." -f $result.targetFilesVerified)
  }
  Write-Step 'All 15 target files are byte-exact in the Git checkout.'

  $authorName = @(& git -C $RepoPath config --get user.name 2>$null)
  $authorNameExitCode = $LASTEXITCODE
  if ($authorNameExitCode -ne 0 -or $authorName.Count -eq 0 -or [string]::IsNullOrWhiteSpace([string]$authorName[0])) {
    Invoke-GitChecked -Arguments @('-C', $RepoPath, 'config', 'user.name', 'Zombieland1234')
  }

  $authorEmail = @(& git -C $RepoPath config --get user.email 2>$null)
  $authorEmailExitCode = $LASTEXITCODE
  if ($authorEmailExitCode -ne 0 -or $authorEmail.Count -eq 0 -or [string]::IsNullOrWhiteSpace([string]$authorEmail[0])) {
    Invoke-GitChecked -Arguments @('-C', $RepoPath, 'config', 'user.email', 'velmere141@gmail.com')
  }

  $addArgs = @('-C', $RepoPath, 'add', '--') + @($targetPaths | ForEach-Object { [string]$_ })
  Invoke-GitChecked -Arguments $addArgs

  & git -C $RepoPath diff --cached --quiet
  $diffCode = $LASTEXITCODE
  if ($diffCode -eq 0) {
    Write-Step 'The exact payload is already present; no new commit is required.'
  }
  elseif ($diffCode -eq 1) {
    Write-Step 'Creating the P58R2 exact payload-admission commit.'
    Invoke-GitChecked -Arguments @('-C', $RepoPath, 'commit', '-m', 'P58R2: admit exact P49 self-contained Windows projection transport')
  }
  else {
    throw ("git diff --cached failed with exit code {0}." -f $diffCode)
  }

  $commitOutput = @(& git -C $RepoPath rev-parse HEAD)
  $revParseExitCode = $LASTEXITCODE
  if ($revParseExitCode -ne 0 -or $commitOutput.Count -eq 0) {
    throw ("Cannot resolve resulting commit SHA; git rev-parse exited with {0}." -f $revParseExitCode)
  }
  $commitSha = ([string]$commitOutput[0]).Trim()
  if ([string]::IsNullOrWhiteSpace($commitSha)) {
    throw 'Cannot resolve resulting commit SHA.'
  }
  $result.commitSha = $commitSha

  if (-not $NoPush) {
    Write-Step 'Pushing the exact admission commit to GitHub.'
    Invoke-GitChecked -Arguments @('-C', $RepoPath, 'push', 'origin', ("HEAD:{0}" -f $Branch))
    $result.pushed = $true
  }
  else {
    Write-Step 'NoPush was requested; the exact commit remains local.'
  }

  $result.status = 'PASS'
  $result.endedAtUtc = [DateTime]::UtcNow.ToString('o')
  $result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $ResultPath -Encoding utf8

  Write-Host ''
  Write-Step ("PASS. Commit: {0}" -f $commitSha)
  if ($result.pushed) {
    Write-Step 'The P49 native Windows workflow should now start automatically.'
    if (-not $NoBrowser) {
      Start-Process ([string]$result.workflowUrl)
    }
  }
  exit 0
}
catch {
  $result.status = 'FAIL'
  $result.failure = $_.Exception.ToString()
  $result.endedAtUtc = [DateTime]::UtcNow.ToString('o')
  $result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $ResultPath -Encoding utf8

  Write-Host ''
  Write-Host '[P58R2] FAIL:' -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Write-Host ("[P58R2] Result written to: {0}" -f $ResultPath)
  exit 1
}
finally {
  Remove-Item -LiteralPath $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
}
